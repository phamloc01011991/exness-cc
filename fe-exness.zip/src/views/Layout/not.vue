<script setup >
</script>
<template >
    <div class="main" style="text-align: center;">
        NOT SUPPORT PC
    </div>
</template>