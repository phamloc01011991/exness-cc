<script setup>

</script>

<template>
    <header>
        <div class="header">
           
        </div>
    </header>
</template>

<style scoped>
header{
  height: 45px;
  position: fixed;
  left:0;
  top: 0;
  width: 100%;
}
</style>
